class App {
  constructor() {
    this.init();
  }
  init() {
    this.days = ["일", "월", "화", "수", "목", "금", "토"];
    this.currentDate = this.getCurrentDate();
    //content box가 뒤늦게 완료. onLoad 이벤트 걸어봤으나 동작 X.
    setTimeout(() => this.fillForm(), 0);
  }

  fillForm() {
    this.$titleInput = document.querySelector("div.field > input");
    this.$content = document.querySelector("div.CodeMirror-code");
    this.getCurrentDate();
    this.$titleInput.value = `${this.currDate.year}${this.currDate.month}${this.currDate.date} (${this.currDate.day})`;
  }

  getCurrentDate() {
    const dateObj = new Date();
    const utc = dateObj.getTime() + dateObj.getTimezoneOffset() * 60 * 1000;
    const KR_DIFF = 9 * 60 * 60 * 1000;

    this.KR_TIME = new Date(utc + KR_DIFF);
    this.currDate = {
      month:
        this.KR_TIME.getMonth() + 1 < 10
          ? "0" + (this.KR_TIME.getMonth() + 1).toString()
          : this.KR_TIME.getMonth() + 1,
      date:
        this.KR_TIME.getDate() < 10
          ? "0" + this.KR_TIME.getDate().toString()
          : this.KR_TIME.getDate(),
      year: this.KR_TIME.getFullYear(),
      day: this.days[this.KR_TIME.getDay()],
    };
  }
}

new App();
